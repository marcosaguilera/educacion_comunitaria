
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscipcionesVistaAsignaturas
 *  08/20/2014 07:29:44
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CalifEstCopy
 *  08/20/2014 07:29:45
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PromocionVistaInscAlumnCurso
 *  08/20/2014 07:29:45
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}

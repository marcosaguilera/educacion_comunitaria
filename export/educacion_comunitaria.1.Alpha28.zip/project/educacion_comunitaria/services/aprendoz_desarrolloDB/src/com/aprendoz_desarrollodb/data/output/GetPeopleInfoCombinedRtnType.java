
package com.aprendoz_desarrollodb.data.output;



/**
 * Generated for query "getPeopleInfoCombined" on 08/28/2014 09:04:43
 * 
 */
public class GetPeopleInfoCombinedRtnType {

    private String codigo;
    private String nombreCompleto;
    private Integer idpersona;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}

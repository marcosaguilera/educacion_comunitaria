
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.ServiciosListadoServiciosAlumnos
 *  08/20/2014 07:29:45
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}

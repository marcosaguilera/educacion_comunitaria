
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TablaAnticiposMatriculas
 *  08/20/2014 07:29:44
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}

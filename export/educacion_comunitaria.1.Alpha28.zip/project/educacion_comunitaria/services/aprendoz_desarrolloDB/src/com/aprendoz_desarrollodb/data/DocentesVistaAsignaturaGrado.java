
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaAsignaturaGrado
 *  08/20/2014 07:29:45
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}

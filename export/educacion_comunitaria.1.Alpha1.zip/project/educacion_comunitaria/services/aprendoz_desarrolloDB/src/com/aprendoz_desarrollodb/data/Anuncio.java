
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anuncio
 *  01/30/2014 12:34:15
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}

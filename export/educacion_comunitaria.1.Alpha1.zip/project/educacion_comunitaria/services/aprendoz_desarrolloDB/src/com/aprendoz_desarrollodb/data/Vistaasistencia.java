
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Vistaasistencia
 *  01/30/2014 12:34:15
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}

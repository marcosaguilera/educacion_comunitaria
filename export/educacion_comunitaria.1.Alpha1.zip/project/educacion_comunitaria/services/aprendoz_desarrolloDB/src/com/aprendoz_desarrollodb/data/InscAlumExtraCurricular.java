
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscAlumExtraCurricular
 *  01/30/2014 12:34:16
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.ServiciosListadoServiciosAlumnos
 *  01/30/2014 12:34:15
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}

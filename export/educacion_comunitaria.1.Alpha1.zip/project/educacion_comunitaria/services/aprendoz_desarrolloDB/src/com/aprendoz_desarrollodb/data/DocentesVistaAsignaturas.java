
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaAsignaturas
 *  01/30/2014 12:34:15
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}

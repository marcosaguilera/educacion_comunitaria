
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaAlumnosActivos
 *  01/30/2014 12:34:15
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}

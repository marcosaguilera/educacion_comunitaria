
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaPersonasGrupoFamiliar
 *  01/30/2014 12:34:15
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}

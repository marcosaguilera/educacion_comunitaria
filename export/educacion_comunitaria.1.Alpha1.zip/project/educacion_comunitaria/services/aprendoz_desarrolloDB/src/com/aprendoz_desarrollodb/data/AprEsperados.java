
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprEsperados
 *  01/30/2014 12:34:15
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}

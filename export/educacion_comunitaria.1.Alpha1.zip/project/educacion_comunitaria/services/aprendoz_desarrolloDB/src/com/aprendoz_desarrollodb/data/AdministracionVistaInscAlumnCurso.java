
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaInscAlumnCurso
 *  01/30/2014 12:34:15
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}

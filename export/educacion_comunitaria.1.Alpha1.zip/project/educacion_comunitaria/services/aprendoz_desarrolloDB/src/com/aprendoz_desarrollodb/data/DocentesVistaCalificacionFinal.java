
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaCalificacionFinal
 *  01/30/2014 12:34:15
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}

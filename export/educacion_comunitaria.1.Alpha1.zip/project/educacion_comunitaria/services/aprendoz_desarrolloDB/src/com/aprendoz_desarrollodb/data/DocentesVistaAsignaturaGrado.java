
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaAsignaturaGrado
 *  01/30/2014 12:34:15
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PadresVistaAprendizajes
 *  01/30/2014 12:34:15
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}

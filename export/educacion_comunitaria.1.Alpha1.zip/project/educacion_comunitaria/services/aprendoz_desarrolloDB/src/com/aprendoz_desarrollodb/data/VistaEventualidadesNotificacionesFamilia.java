
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEventualidadesNotificacionesFamilia
 *  01/30/2014 12:34:15
 * 
 */
public class VistaEventualidadesNotificacionesFamilia {

    private VistaEventualidadesNotificacionesFamiliaId id;

    public VistaEventualidadesNotificacionesFamiliaId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

}

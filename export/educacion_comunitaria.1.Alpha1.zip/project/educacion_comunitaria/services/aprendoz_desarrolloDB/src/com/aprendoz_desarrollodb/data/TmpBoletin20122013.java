
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpBoletin20122013
 *  01/30/2014 12:34:15
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}

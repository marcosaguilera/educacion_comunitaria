
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VProfesorAsignaturaCompleto
 *  01/30/2014 12:34:16
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}

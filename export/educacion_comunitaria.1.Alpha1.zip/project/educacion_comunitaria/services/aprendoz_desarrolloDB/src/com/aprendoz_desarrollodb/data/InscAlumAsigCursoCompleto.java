
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscAlumAsigCursoCompleto
 *  01/30/2014 12:34:15
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}

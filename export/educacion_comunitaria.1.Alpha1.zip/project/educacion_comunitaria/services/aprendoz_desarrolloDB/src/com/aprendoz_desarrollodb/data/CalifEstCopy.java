
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CalifEstCopy
 *  01/30/2014 12:34:15
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PadresVistaRecursos
 *  01/30/2014 12:34:16
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}

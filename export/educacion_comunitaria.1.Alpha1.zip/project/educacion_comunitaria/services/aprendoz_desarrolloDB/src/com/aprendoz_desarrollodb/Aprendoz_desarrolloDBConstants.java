
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  01/30/2014 12:34:28
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getPeopleInfoCombinedQueryName = "getPeopleInfoCombined";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardNoCalificados
 *  01/30/2014 12:34:15
 * 
 */
public class VistaDashboardNoCalificados {

    private VistaDashboardNoCalificadosId id;

    public VistaDashboardNoCalificadosId getId() {
        return id;
    }

    public void setId(VistaDashboardNoCalificadosId id) {
        this.id = id;
    }

}

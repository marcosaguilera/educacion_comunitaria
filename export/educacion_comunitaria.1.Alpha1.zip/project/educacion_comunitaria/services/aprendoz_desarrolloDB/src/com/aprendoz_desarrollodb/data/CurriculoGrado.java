
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CurriculoGrado
 *  01/30/2014 12:34:16
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}

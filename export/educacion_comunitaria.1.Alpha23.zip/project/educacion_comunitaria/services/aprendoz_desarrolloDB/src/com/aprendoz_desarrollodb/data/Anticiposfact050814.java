
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anticiposfact050814
 *  08/20/2014 07:29:44
 * 
 */
public class Anticiposfact050814 {

    private String codigo;
    private Double pension;
    private Double alimentacion;
    private Double transporte;
    private Double totalAnticipos;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Double getPension() {
        return pension;
    }

    public void setPension(Double pension) {
        this.pension = pension;
    }

    public Double getAlimentacion() {
        return alimentacion;
    }

    public void setAlimentacion(Double alimentacion) {
        this.alimentacion = alimentacion;
    }

    public Double getTransporte() {
        return transporte;
    }

    public void setTransporte(Double transporte) {
        this.transporte = transporte;
    }

    public Double getTotalAnticipos() {
        return totalAnticipos;
    }

    public void setTotalAnticipos(Double totalAnticipos) {
        this.totalAnticipos = totalAnticipos;
    }

}

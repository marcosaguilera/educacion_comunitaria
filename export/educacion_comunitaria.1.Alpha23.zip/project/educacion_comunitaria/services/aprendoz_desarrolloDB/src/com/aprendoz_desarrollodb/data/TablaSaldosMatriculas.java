
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TablaSaldosMatriculas
 *  08/20/2014 07:29:45
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}

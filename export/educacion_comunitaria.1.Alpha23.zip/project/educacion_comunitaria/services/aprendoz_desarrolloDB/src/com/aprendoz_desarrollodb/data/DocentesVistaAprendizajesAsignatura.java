
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaAprendizajesAsignatura
 *  08/20/2014 07:29:46
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaAsignaturaEstudiantes
 *  08/20/2014 07:29:45
 * 
 */
public class VistaAsignaturaEstudiantes {

    private VistaAsignaturaEstudiantesId id;

    public VistaAsignaturaEstudiantesId getId() {
        return id;
    }

    public void setId(VistaAsignaturaEstudiantesId id) {
        this.id = id;
    }

}

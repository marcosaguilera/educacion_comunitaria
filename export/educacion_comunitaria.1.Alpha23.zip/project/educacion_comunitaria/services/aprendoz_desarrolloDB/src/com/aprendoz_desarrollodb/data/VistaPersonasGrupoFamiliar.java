
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaPersonasGrupoFamiliar
 *  08/20/2014 07:29:45
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}

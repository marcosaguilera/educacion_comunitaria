
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprLogrados
 *  08/20/2014 07:29:45
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anuncio
 *  08/20/2014 07:29:45
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}

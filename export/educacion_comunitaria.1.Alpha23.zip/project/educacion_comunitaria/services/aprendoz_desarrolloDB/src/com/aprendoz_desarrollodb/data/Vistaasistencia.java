
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Vistaasistencia
 *  08/20/2014 07:29:45
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}

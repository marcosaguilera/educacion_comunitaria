
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaMatriculasGraficasTotalDia
 *  08/20/2014 07:29:44
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprEsperados
 *  08/20/2014 07:29:46
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}

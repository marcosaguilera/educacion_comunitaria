
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anticipos
 *  08/20/2014 07:29:45
 * 
 */
public class Anticipos {

    private Integer idAnticipos;
    private String codigo;

    public Integer getIdAnticipos() {
        return idAnticipos;
    }

    public void setIdAnticipos(Integer idAnticipos) {
        this.idAnticipos = idAnticipos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}

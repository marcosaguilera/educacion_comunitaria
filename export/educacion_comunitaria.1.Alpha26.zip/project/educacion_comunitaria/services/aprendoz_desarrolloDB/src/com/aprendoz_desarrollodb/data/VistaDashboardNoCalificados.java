
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardNoCalificados
 *  08/20/2014 07:29:44
 * 
 */
public class VistaDashboardNoCalificados {

    private VistaDashboardNoCalificadosId id;

    public VistaDashboardNoCalificadosId getId() {
        return id;
    }

    public void setId(VistaDashboardNoCalificadosId id) {
        this.id = id;
    }

}

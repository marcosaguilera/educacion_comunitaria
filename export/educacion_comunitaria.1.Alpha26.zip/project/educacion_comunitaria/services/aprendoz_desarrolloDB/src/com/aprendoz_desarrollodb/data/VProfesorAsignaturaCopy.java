
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VProfesorAsignaturaCopy
 *  08/20/2014 07:29:45
 * 
 */
public class VProfesorAsignaturaCopy {

    private VProfesorAsignaturaCopyId id;

    public VProfesorAsignaturaCopyId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCopyId id) {
        this.id = id;
    }

}

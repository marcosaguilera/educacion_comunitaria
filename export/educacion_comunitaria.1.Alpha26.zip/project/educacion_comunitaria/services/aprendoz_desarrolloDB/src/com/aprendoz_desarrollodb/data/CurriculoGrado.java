
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CurriculoGrado
 *  08/20/2014 07:29:45
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}

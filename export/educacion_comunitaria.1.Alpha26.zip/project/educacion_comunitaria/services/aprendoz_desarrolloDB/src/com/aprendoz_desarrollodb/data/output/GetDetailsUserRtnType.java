
package com.aprendoz_desarrollodb.data.output;



/**
 * Generated for query "getDetailsUser" on 08/28/2014 09:04:43
 * 
 */
public class GetDetailsUserRtnType {

    private String u;
    private Integer id;
    private String c;

    public String getU() {
        return u;
    }

    public void setU(String u) {
        this.u = u;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

}

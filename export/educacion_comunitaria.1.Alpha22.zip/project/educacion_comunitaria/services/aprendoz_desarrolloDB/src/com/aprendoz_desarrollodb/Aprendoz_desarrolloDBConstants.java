
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  08/28/2014 09:04:48
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getPeopleInfoCombinedQueryName = "getPeopleInfoCombined";
    public final static String getRecursoByIdQueryName = "getRecursoById";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";
    public final static String getterOneQueryName = "getterOne";
    public final static String getterSyQueryName = "getterSy";
    public final static String getDetailsUserQueryName = "getDetailsUser";

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEnvioCorreo
 *  08/20/2014 07:29:44
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscAlumAsigCursoCompleto
 *  08/20/2014 07:29:44
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}

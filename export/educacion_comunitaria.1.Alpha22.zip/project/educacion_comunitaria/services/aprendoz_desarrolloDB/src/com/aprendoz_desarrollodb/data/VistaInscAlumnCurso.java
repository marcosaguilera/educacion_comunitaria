
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaInscAlumnCurso
 *  08/20/2014 07:29:45
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}

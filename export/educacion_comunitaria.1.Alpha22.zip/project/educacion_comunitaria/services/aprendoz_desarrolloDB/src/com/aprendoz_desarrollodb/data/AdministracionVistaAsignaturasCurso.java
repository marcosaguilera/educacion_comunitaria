
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaAsignaturasCurso
 *  08/20/2014 07:29:45
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}

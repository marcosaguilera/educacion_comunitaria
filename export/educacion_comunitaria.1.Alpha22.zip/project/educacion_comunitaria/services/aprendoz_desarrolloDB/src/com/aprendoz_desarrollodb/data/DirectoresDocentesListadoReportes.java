
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DirectoresDocentesListadoReportes
 *  08/20/2014 07:29:45
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}

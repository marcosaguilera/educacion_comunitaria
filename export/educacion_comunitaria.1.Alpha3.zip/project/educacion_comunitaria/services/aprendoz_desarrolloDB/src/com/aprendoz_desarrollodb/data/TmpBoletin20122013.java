
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpBoletin20122013
 *  02/04/2014 12:37:43
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}

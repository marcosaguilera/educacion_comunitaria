
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  02/04/2014 12:37:56
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getPeopleInfoCombinedQueryName = "getPeopleInfoCombined";
    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PromocionVistaInscAlumnCurso
 *  02/04/2014 12:37:42
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}

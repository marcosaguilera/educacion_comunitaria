
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.FacturacionSapiens
 *  02/04/2014 12:37:42
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}

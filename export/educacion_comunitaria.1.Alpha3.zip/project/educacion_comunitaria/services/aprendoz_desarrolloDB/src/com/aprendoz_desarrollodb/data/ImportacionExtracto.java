
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.ImportacionExtracto
 *  02/04/2014 12:37:43
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}

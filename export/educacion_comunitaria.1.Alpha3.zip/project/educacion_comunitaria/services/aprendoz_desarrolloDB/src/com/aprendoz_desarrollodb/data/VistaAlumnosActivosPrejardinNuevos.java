
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaAlumnosActivosPrejardinNuevos
 *  02/04/2014 12:37:42
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}

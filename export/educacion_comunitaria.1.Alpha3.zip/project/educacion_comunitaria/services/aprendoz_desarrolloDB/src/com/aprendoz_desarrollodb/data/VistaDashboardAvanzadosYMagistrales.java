
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardAvanzadosYMagistrales
 *  02/04/2014 12:37:42
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Salon
 *  02/04/2014 12:37:42
 * 
 */
public class Salon {

    private Integer idSalon;
    private String numeroSalon;

    public Integer getIdSalon() {
        return idSalon;
    }

    public void setIdSalon(Integer idSalon) {
        this.idSalon = idSalon;
    }

    public String getNumeroSalon() {
        return numeroSalon;
    }

    public void setNumeroSalon(String numeroSalon) {
        this.numeroSalon = numeroSalon;
    }

}

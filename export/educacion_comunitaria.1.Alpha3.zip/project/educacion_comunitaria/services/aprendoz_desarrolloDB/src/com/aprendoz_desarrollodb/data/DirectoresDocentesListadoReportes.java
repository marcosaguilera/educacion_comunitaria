
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DirectoresDocentesListadoReportes
 *  02/04/2014 12:37:43
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}

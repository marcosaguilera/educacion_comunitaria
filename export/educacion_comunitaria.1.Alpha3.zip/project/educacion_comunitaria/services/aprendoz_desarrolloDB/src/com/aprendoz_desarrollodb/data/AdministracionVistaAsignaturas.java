
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaAsignaturas
 *  02/04/2014 12:37:42
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}

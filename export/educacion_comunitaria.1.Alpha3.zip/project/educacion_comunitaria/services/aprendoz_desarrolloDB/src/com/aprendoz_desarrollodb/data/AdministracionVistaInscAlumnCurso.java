
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaInscAlumnCurso
 *  02/04/2014 12:37:42
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}

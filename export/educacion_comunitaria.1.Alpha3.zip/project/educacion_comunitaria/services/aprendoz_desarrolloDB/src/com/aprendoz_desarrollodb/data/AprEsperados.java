
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprEsperados
 *  02/04/2014 12:37:43
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}

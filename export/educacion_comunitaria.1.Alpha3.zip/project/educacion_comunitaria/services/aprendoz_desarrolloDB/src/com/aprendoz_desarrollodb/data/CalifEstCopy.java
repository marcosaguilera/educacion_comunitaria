
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CalifEstCopy
 *  02/04/2014 12:37:42
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}

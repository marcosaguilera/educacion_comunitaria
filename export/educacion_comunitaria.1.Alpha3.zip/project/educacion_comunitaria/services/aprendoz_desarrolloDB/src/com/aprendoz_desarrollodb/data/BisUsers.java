
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.BisUsers
 *  02/04/2014 12:37:43
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscipcionesVistaAsignaturas
 *  02/04/2014 12:37:42
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesInscCursoAsignatura
 *  02/04/2014 12:37:42
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}

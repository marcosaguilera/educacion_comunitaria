
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PadresVistaActividades
 *  02/04/2014 12:37:42
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.DocentesVistaAprendizajesAsignatura
 *  02/04/2014 12:37:43
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}

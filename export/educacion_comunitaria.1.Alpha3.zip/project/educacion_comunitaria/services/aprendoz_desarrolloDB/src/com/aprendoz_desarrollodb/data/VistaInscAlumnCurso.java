
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaInscAlumnCurso
 *  02/04/2014 12:37:42
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}

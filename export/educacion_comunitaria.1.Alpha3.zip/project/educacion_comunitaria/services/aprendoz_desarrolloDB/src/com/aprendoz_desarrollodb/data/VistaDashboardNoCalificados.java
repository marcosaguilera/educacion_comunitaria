
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardNoCalificados
 *  02/04/2014 12:37:43
 * 
 */
public class VistaDashboardNoCalificados {

    private VistaDashboardNoCalificadosId id;

    public VistaDashboardNoCalificadosId getId() {
        return id;
    }

    public void setId(VistaDashboardNoCalificadosId id) {
        this.id = id;
    }

}

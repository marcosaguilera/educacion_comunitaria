
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PersonaEdad
 *  02/04/2014 12:37:43
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anticipos
 *  02/04/2014 12:37:43
 * 
 */
public class Anticipos {

    private Integer idAnticipos;
    private String codigo;

    public Integer getIdAnticipos() {
        return idAnticipos;
    }

    public void setIdAnticipos(Integer idAnticipos) {
        this.idAnticipos = idAnticipos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}

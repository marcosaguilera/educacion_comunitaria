
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEnvioCorreo
 *  02/04/2014 12:37:43
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}

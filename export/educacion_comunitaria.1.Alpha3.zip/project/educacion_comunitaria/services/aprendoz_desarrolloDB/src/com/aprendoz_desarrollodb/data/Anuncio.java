
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anuncio
 *  02/04/2014 12:37:42
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpEnrLog
 *  02/04/2014 12:37:42
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}

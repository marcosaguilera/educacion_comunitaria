
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaPersonasGrupoFamiliar
 *  02/04/2014 12:37:42
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}

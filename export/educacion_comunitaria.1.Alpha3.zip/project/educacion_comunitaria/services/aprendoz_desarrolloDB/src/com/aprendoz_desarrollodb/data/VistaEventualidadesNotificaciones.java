
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEventualidadesNotificaciones
 *  02/04/2014 12:37:43
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}

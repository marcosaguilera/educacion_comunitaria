dojo.declare("Main", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
costosLiveForm1BeginInsert: function(inSender) {
this.gradoLookup1.setDisplayValue("EDUCACIÓN COMUNITARIA");
this.syLookup2.setDisplayValue("2013-2014");
this.lsTipoCosto.update();
},
_end: 0
});

Main.widgets = {
varTemplateLogout: ["wm.LogoutVariable", {}, {}, {
input: ["wm.ServiceInput", {"type":"logoutInputs"}, {}]
}],
costosLiveVariable1: ["wm.LiveVariable", {"matchMode":"anywhere","maxResults":100,"type":"com.aprendoz_desarrollodb.data.Costos"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"codigo_tipo.dataValue","targetProperty":"filter.tipoCosto"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"comunity_nombre.dataValue","targetProperty":"filter.nombreProducto"}, {}]
}],
liveView: ["wm.LiveView", {"dataType":"com.aprendoz_desarrollodb.data.Costos","related":["grado","sy"],"view":[
{"caption":"IdCosto","sortable":true,"dataIndex":"idCosto","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},
{"caption":"Codigo","sortable":true,"dataIndex":"codigo","type":"java.lang.String","displayType":"Text","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},
{"caption":"NombreProducto","sortable":true,"dataIndex":"nombreProducto","type":"java.lang.String","displayType":"Text","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},
{"caption":"Descripcion","sortable":true,"dataIndex":"descripcion","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null},
{"caption":"Valor","sortable":true,"dataIndex":"valor","type":"java.lang.Double","displayType":"Number","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":4,"subType":null},
{"caption":"Nuevo","sortable":true,"dataIndex":"nuevo","type":"java.lang.Boolean","displayType":"CheckBox","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":5,"subType":null},
{"caption":"Obligatorio","sortable":true,"dataIndex":"obligatorio","type":"java.lang.Boolean","displayType":"CheckBox","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":6,"subType":null},
{"caption":"Positivo","sortable":true,"dataIndex":"positivo","type":"java.lang.Boolean","displayType":"CheckBox","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":7,"subType":null},
{"caption":"Anual","sortable":true,"dataIndex":"anual","type":"java.lang.Boolean","displayType":"CheckBox","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":8,"subType":null},
{"caption":"TipoCosto","sortable":true,"dataIndex":"tipoCosto","type":"java.lang.Integer","displayType":"Number","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":9,"subType":null},
{"caption":"IdGrado","sortable":true,"dataIndex":"grado.idGrado","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},
{"caption":"Grado","sortable":true,"dataIndex":"grado.grado","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},
{"caption":"Grade","sortable":true,"dataIndex":"grado.grade","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},
{"caption":"GradoSapiens","sortable":true,"dataIndex":"grado.gradoSapiens","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null},
{"caption":"IdSy","sortable":true,"dataIndex":"sy.idSy","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},
{"caption":"SchoolYear","sortable":true,"dataIndex":"sy.schoolYear","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},
{"caption":"FechaDesde","sortable":true,"dataIndex":"sy.fechaDesde","type":"java.util.Date","displayType":"Date","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},
{"caption":"FechaHasta","sortable":true,"dataIndex":"sy.fechaHasta","type":"java.util.Date","displayType":"Date","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null}
]}, {}]
}],
lsTipoCosto: ["wm.LiveVariable", {"autoUpdate":false,"inFlightBehavior":"executeLast","startUpdate":false,"type":"com.aprendoz_desarrollodb.data.TipoCosto"}, {}, {
liveView: ["wm.LiveView", {"dataType":"com.aprendoz_desarrollodb.data.TipoCosto","view":[
{"caption":"IdTipoCosto","sortable":true,"dataIndex":"idTipoCosto","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},
{"caption":"TipoCosto","sortable":true,"dataIndex":"tipoCosto","type":"java.lang.String","displayType":"Text","required":true,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null}
]}, {}]
}],
costosDialog: ["wm.DesignableDialog", {"border":"1","desktopHeight":"490px","height":"490px","styles":{"backgroundColor":"#e8e8e8"},"title":"Costos","width":"500px","containerWidgetId":"containerWidget","buttonBarId":"buttonBar"}, {}, {
containerWidget: ["wm.Container", {"_classes":{"domNode":["wmdialogcontainer","MainContent"]},"autoScroll":true,"height":"100%","horizontalAlign":"left","padding":"5","verticalAlign":"top","width":"100%"}, {}, {
costosLiveForm1: ["wm.LiveForm", {"alwaysPopulateEditors":true,"fitToContentHeight":true,"height":"378px","horizontalAlign":"left","liveEditing":false,"margin":"4","styles":{},"verticalAlign":"top"}, {"onSuccess":"costosLivePanel2.popupLiveFormSuccess","onBeginInsert":"costosLiveForm1BeginInsert"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"costosDojoGrid.selectedItem","targetProperty":"dataSet"}, {}]
}],
idCostoEditor1: ["wm.Number", {"caption":"Id costo","captionAlign":"right","captionSize":"140px","changeOnKey":true,"emptyValue":"zero","formField":"idCosto","height":"26px","styles":{},"width":"100%"}, {}],
codigoEditor1: ["wm.Text", {"caption":"Código","captionAlign":"right","captionSize":"140px","changeOnKey":true,"emptyValue":"emptyString","formField":"codigo","height":"26px","maxChars":6,"required":true,"styles":{},"width":"100%"}, {}],
nombreProductoEditor1: ["wm.Text", {"caption":"Nombre","captionAlign":"right","captionSize":"140px","changeOnKey":true,"emptyValue":"emptyString","formField":"nombreProducto","height":"26px","maxChars":50,"required":true,"styles":{},"width":"100%"}, {}],
descripcionEditor1: ["wm.LargeTextArea", {"caption":"Descripción","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"desktopHeight":"72px","emptyValue":"emptyString","formField":"descripcion","height":"72px","maxChars":65535,"styles":{},"width":"100%"}, {}],
valorEditor1: ["wm.Number", {"caption":"Valor","captionAlign":"right","captionSize":"140px","changeOnKey":true,"emptyValue":"zero","formField":"valor","height":"26px","required":true,"width":"100%"}, {}],
nuevoEditor1: ["wm.Checkbox", {"caption":"Nuevo","captionAlign":"right","captionSize":"140px","displayValue":false,"formField":"nuevo","height":"26px","width":"100%"}, {}],
obligatorioEditor1: ["wm.Checkbox", {"caption":"Obligatorio","captionAlign":"right","captionSize":"140px","displayValue":false,"formField":"obligatorio","height":"26px","width":"100%"}, {}],
positivoEditor1: ["wm.Checkbox", {"caption":"Positivo","captionAlign":"right","captionSize":"140px","displayValue":true,"formField":"positivo","height":"26px","width":"100%"}, {}],
anualEditor1: ["wm.Checkbox", {"caption":"Anual","captionAlign":"right","captionSize":"140px","displayValue":false,"formField":"anual","height":"26px","width":"100%"}, {}],
tipoCostoSelectEditor1: ["wm.SelectMenu", {"caption":"Tipo costo","captionAlign":"right","captionSize":"140px","dataField":"idTipoCosto","dataType":"com.aprendoz_desarrollodb.data.TipoCosto","displayField":"tipoCosto","formField":"tipoCosto","height":"30px","width":"100%"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"lsTipoCosto","targetProperty":"dataSet"}, {}]
}]
}],
gradoLookup1: ["wm.Lookup", {"caption":"Grado ","captionAlign":"right","captionSize":"140px","dataType":"com.aprendoz_desarrollodb.data.Grado","displayField":"grado","formField":"grado","height":"30px","required":true,"width":"100%"}, {}],
syLookup1: ["wm.Lookup", {"caption":"Año escolar","captionAlign":"right","captionSize":"140px","dataType":"com.aprendoz_desarrollodb.data.Sy","displayField":"schoolYear","formField":"sy","height":"30px","required":true,"width":"100%"}, {}]
}]
}],
buttonBar: ["wm.ButtonBarPanel", {"border":"1,0,0,0","borderColor":"#eeeeee","height":"60px","showing":false}, {}, {
costosSaveButton: ["wm.Button", {"border":"1","caption":"Guardar","height":"30px"}, {"onclick":"costosLiveForm1.saveDataIfValid"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"costosLiveForm1.invalid","targetId":null,"targetProperty":"disabled"}, {}]
}]
}],
costosCancelButton: ["wm.Button", {"border":"1","caption":"Cancelar","height":"30px"}, {"onclick":"costosDialog.hide","onclick1":"costosLiveForm1.cancelEdit"}]
}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","styles":{},"verticalAlign":"top"}, {}, {
MenuonTop: ["wm.Panel", {"autoScroll":true,"height":"100%","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
panelCenter: ["wm.Panel", {"height":"100%","horizontalAlign":"left","minDesktopHeight":600,"minHeight":600,"verticalAlign":"top","width":"900px"}, {}, {
panelHeader: ["wm.HeaderContentPanel", {"height":"65px","horizontalAlign":"left","layoutKind":"left-to-right","lock":true,"padding":"0,10,0,10","verticalAlign":"middle","width":"100%"}, {}, {
spacer1: ["wm.Spacer", {"height":"48px","styles":{},"width":"100%"}, {}],
panel10: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"middle","width":"300px"}, {}, {
panel15: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"middle","width":"100%"}, {}, {
text1: ["wm.Text", {"dataValue":undefined,"desktopHeight":"35px","displayValue":"","height":"35px","placeHolder":"Search","resetButton":true,"styles":{},"width":"100%"}, {}],
picture5: ["wm.Picture", {"height":"16px","source":"lib/images/silkIcons/zoom.png","width":"16px"}, {}]
}]
}],
logoutButton: ["wm.Button", {"border":"1","caption":"Salir","desktopHeight":"35px","height":"35px","imageIndex":42,"imageList":"app.silkIconList","margin":"4","width":"122px"}, {"onclick":"varTemplateLogout"}]
}],
panelContent: ["wm.MainContentPanel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
comunity_table: ["wm.FancyPanel", {"title":"Gestión de Educación Comunitaria"}, {}, {
educomLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"right","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"educomDialog","targetId":null,"targetProperty":"dialog"}, {}],
wire1: ["wm.Wire", {"source":"educomLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire2: ["wm.Wire", {"source":"educomDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire3: ["wm.Wire", {"source":"educomSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
breadcrumbLayers1: ["wm.TabLayers", {"clientBorderColor":"#ffffff","headerWidth":"150px","layoutKind":"left-to-right","styles":{},"verticalButtons":true}, {}, {
costos: ["wm.Layer", {"border":"1","borderColor":"#ffffff","caption":"<img src=\"resources/images/buttons/pesos.png\" width=\"14px\" height=\"14px\">&nbsp;&nbsp;Costos","horizontalAlign":"left","roles":["10"],"styles":{},"themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
costosLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"costosDialog","targetId":null,"targetProperty":"dialog"}, {}],
wire1: ["wm.Wire", {"source":"costosLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire2: ["wm.Wire", {"source":"costosDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire3: ["wm.Wire", {"source":"costosSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
top_header_extra: ["wm.Panel", {"height":"43px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"5","styles":{},"verticalAlign":"middle","width":"100%"}, {}, {
codigo_tipo: ["wm.Text", {"caption":undefined,"captionSize":"20px","disabled":true,"displayValue":"2","height":"30px","showing":false}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"2","targetProperty":"dataValue"}, {}]
}]
}],
comunity_nombre: ["wm.Text", {"caption":"Curso extracurricular","captionSize":"150px","dataValue":undefined,"displayValue":"","height":"100%","width":"392px"}, {}],
comunity_search: ["wm.Button", {"_classes":{"domNode":["Success"]},"border":"1","borderColor":"#51a351","caption":"Buscar","height":"100%","imageIndex":67,"imageList":"app.silkIconList","width":"105px"}, {"onclick":"costosLiveVariable1"}]
}],
costosLivePanel2: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"costosDialog","targetId":null,"targetProperty":"dialog"}, {}],
wire1: ["wm.Wire", {"source":"costosLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire2: ["wm.Wire", {"source":"costosDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire3: ["wm.Wire", {"source":"costosSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
costosDojoGrid: ["wm.DojoGrid", {"columns":[
{"show":false,"field":"idCosto","title":"IdCosto","width":"80px","align":"right","formatFunc":"","mobileColumn":false},
{"show":true,"field":"codigo","title":"Código","width":"80px","align":"left","formatFunc":"","mobileColumn":false},
{"show":true,"field":"nombreProducto","title":"Producto","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"descripcion","title":"Descripcion","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":true,"field":"valor","title":"Valor","width":"80px","align":"left","formatFunc":"wm_number_formatter","mobileColumn":false},
{"show":false,"field":"nuevo","title":"Nuevo","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"obligatorio","title":"Obligatorio","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"positivo","title":"Positivo","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"anual","title":"Anual","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"tipoCosto","title":"TipoCosto","width":"80px","align":"right","formatFunc":"","mobileColumn":false},
{"show":false,"field":"grado.idGrado","title":"IdGrado","width":"80px","align":"right","formatFunc":"","mobileColumn":false},
{"show":false,"field":"grado.grado","title":"Grado","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"grado.grade","title":"Grade","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"grado.gradoSapiens","title":"GradoSapiens","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"sy.idSy","title":"IdSy","width":"80px","align":"right","formatFunc":"","mobileColumn":false},
{"show":false,"field":"sy.schoolYear","title":"SchoolYear","width":"100%","align":"left","formatFunc":"","mobileColumn":false},
{"show":false,"field":"sy.fechaDesde","title":"FechaDesde","width":"80px","align":"left","formatFunc":"wm_date_formatter","mobileColumn":false},
{"show":false,"field":"sy.fechaHasta","title":"FechaHasta","width":"80px","align":"left","formatFunc":"wm_date_formatter","mobileColumn":false},
{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>\" +\n\"Código: \" + ${codigo} +\n\"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Producto: \" + ${nombreProducto}\n + \"</div>\"\n\n+ \"<div class='MobileRow'>\" +\n\"Valor: \" + ${wm.runtimeId}.formatCell(\"valor\", ${valor}, ${this}, ${wm.rowId})\n + \"</div>\"\n\n","mobileColumn":true}
],"dsType":"com.aprendoz_desarrollodb.data.Costos","height":"100%"}, {"onCellDblClick":"costosLivePanel2.popupLivePanelEdit"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"costosLiveVariable1","targetProperty":"dataSet"}, {}]
}]
}],
costosGridButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","showing":false,"verticalAlign":"top","width":"100%"}, {}, {
costosNewButton: ["wm.Button", {"border":"1","caption":"Nuevo","height":"30px"}, {"onclick":"costosLivePanel2.popupLivePanelInsert"}],
costosUpdateButton: ["wm.Button", {"border":"1","caption":"Modificar","height":"30px"}, {"onclick":"costosLivePanel2.popupLivePanelEdit"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"costosDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
}]
}],
costosDeleteButton: ["wm.Button", {"border":"1","caption":"Eliminar","height":"30px"}, {"onclick":"costosLiveForm1.deleteData"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"costosDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
}]
}]
}]
}]
}]
}],
Cursos_extracurriculares: ["wm.Layer", {"border":"1","borderColor":"#ffffff","caption":"<img src=\"resources/images/buttons/cursos.png\" width=\"14px\" height=\"14px\">&nbsp;&nbsp;Cursos","horizontalAlign":"left","styles":{},"themeStyleType":"ContentPanel","verticalAlign":"top"}, {}],
inscripciones: ["wm.Layer", {"border":"1","borderColor":"#ffffff","caption":"<img src=\"resources/images/buttons/users.png\" width=\"14px\" height=\"14px\">&nbsp;&nbsp;Inscripciones","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}]
}]
}]
}]
}],
panelFooter: ["wm.HeaderContentPanel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
edFooterLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","caption":"Copyright 2013-2014 Colegio Rochester","height":"100%","padding":"4","width":"100%"}, {}]
}]
}]
}]
}]
};

Main.prototype._cssText = '#main_costosDojoGrid{\
cursor: pointer;\
}\
#main_breadcrumbLayers1_decorator_button1 {\
background-color: #EEB422;\
color: #fff;\
border: 0px !important;\
}\
#main_breadcrumbLayers1_decorator_button2 {\
background-color: #BE2625;\
color: #fff;\
border: 0px !important;\
}\
#main_breadcrumbLayers1_decorator_button3 {\
background-color: deepskyblue;\
color: #fff;\
border: 0px !important;\
}\
';
Main.prototype._htmlText = '';
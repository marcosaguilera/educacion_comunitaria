dojo.declare("Main", wm.Page, {
	start: function() {
		
	},
	"preferredDevice": "desktop",

	costosLiveForm1BeginInsert: function(inSender) {
	    this.gradoLookup1.setDisplayValue("EDUCACIÓN COMUNITARIA");
        this.syLookup2.setDisplayValue("2013-2014");
        this.lsTipoCosto.update();
	},
	_end: 0
});
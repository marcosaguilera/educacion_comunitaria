
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AprLogrados
 *  01/27/2014 12:28:27
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}

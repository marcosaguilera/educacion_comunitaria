
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaAlumnosActivos
 *  01/27/2014 12:28:27
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}

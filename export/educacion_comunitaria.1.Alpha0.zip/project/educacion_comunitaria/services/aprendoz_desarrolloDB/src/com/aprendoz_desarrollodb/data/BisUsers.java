
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.BisUsers
 *  01/27/2014 12:28:27
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}

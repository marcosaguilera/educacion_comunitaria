
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscAlumExtraCurricular
 *  01/27/2014 12:28:27
 * 
 */
public class InscAlumExtraCurricular {

    private Integer inscAlumExtraCurricularId;

    public Integer getInscAlumExtraCurricularId() {
        return inscAlumExtraCurricularId;
    }

    public void setInscAlumExtraCurricularId(Integer inscAlumExtraCurricularId) {
        this.inscAlumExtraCurricularId = inscAlumExtraCurricularId;
    }

}

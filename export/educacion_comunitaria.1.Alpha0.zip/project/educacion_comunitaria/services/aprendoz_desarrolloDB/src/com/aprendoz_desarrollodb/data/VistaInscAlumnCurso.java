
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaInscAlumnCurso
 *  01/27/2014 12:28:27
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}

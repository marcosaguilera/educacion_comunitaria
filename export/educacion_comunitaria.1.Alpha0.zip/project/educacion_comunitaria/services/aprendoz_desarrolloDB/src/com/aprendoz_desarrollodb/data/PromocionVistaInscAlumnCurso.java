
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PromocionVistaInscAlumnCurso
 *  01/27/2014 12:28:27
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CurriculoGrado
 *  01/27/2014 12:28:27
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}

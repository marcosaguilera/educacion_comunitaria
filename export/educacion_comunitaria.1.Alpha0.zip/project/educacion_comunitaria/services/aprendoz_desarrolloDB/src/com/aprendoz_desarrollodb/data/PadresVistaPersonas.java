
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.PadresVistaPersonas
 *  01/27/2014 12:28:27
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}

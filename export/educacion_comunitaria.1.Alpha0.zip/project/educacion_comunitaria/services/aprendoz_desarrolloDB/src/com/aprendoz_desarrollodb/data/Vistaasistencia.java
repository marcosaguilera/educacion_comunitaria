
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Vistaasistencia
 *  01/27/2014 12:28:27
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}

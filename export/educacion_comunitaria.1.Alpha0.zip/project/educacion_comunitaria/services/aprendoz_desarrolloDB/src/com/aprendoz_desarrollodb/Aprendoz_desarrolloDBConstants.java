
package com.aprendoz_desarrollodb;



/**
 *  Query names for service "aprendoz_desarrolloDB"
 *  01/27/2014 12:28:39
 * 
 */
public class Aprendoz_desarrolloDBConstants {

    public final static String getTipoPersonaByIdQueryName = "getTipoPersonaById";

}

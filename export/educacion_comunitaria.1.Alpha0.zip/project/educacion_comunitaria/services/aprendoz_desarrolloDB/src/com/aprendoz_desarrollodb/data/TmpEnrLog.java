
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.TmpEnrLog
 *  01/27/2014 12:28:27
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.CalifEstCopy
 *  01/27/2014 12:28:27
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}

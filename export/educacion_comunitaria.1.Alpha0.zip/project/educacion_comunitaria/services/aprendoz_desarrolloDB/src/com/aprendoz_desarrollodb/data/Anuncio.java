
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.Anuncio
 *  01/27/2014 12:28:27
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}

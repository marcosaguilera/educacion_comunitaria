
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.AdministracionVistaAsignaturas
 *  01/27/2014 12:28:27
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}

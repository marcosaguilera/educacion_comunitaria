
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.InscipcionesVistaAsignaturas
 *  01/27/2014 12:28:27
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}

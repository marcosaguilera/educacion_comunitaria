
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaEventualidadesNotificacionesFamilia
 *  01/27/2014 12:28:27
 * 
 */
public class VistaEventualidadesNotificacionesFamilia {

    private VistaEventualidadesNotificacionesFamiliaId id;

    public VistaEventualidadesNotificacionesFamiliaId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

}

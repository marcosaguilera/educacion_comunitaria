
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VProfesorAsignaturaCompleto
 *  01/27/2014 12:28:27
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}

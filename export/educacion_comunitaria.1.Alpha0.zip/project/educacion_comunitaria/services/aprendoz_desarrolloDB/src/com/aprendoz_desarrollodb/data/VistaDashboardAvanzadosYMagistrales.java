
package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaDashboardAvanzadosYMagistrales
 *  01/27/2014 12:28:27
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}


package com.aprendoz_desarrollodb.data;



/**
 *  aprendoz_desarrolloDB.VistaMatriculasGraficasTotalDia
 *  01/27/2014 12:28:28
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
